import React from "react";
import CardList from "./components/CardList";
import "./App.css";

function App() {
  return (
    <div className="App" >
     
      
      <CardList />
    </div>
  );
}

export default App;

