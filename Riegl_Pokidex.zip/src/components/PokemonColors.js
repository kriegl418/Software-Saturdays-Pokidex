import React from 'react';

const PokemonColors = ({ pokemon, setAvgColor }) => {
  const colors = pokemon.map(p => {
    switch (p.color) {
      case 'fire':
        return '#fd7e24';
      case 'water':
        return '#4591c4';
      case 'electric':
        return '#eed535';
      case 'grass':
        return '#9bcc50';
      case 'ice':
        return '#51c4e7';
      case 'fighting':
        return '#d56723';
      case 'poison':
        return '#b97fc9';
      case 'ground':
        return '#ab9842';
      case 'flying':
        return '#3dc7ef';
      case 'psychic':
        return '#f366b9';
      case 'bug':
        return '#729f3f';
      case 'rock':
        return '#a38c21';
      case 'ghost':
        return '#7b62a3';
      case 'dragon':
        return '#7038f8';
      case 'dark':
        return '#707070';
      case 'steel':
        return '#9eb7b8';
      case 'fairy':
        return '#fdb9e9';
      default:
        return '#ffffff';
    }
  });

  const avgColor = ((colors) => {
    const numColors = colors.length;
    let red = 0;
    let green = 0;
    let blue = 0;

    colors.forEach(c => {
      red += parseInt(c.slice(1, 3), 16);
      green += parseInt(c.slice(3, 5), 16);
      blue += parseInt(c.slice(5, 7), 16);
    });

    red /= numColors * 1.0;
    green /= numColors * 1.0;
    blue /= numColors * 1.0;

    return `#${Math.round(red).toString(16)}${Math.round(green).toString(16)}${Math.round(blue).toString(16)}`;
  })(colors);

  setAvgColor(avgColor);

  return (
    <>
      <div style={{ backgroundColor: avgColor, height: '50px', width: '50px', marginBottom: '20px' }}></div>
    </>
  );
};

export default PokemonColors;
