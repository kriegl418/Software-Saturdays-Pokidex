import React from "react";
import { Card } from "react-bootstrap";

const CardItem = ({ card }) => {
  return (
    <div className="card-item">
      <Card style={{ width: "18rem" }}>
        <Card.Img variant="top" src={card.images.small} />
        <Card.Body>
          <Card.Title>{card.name}</Card.Title>
          <Card.Text>{card.rarity}</Card.Text>
        </Card.Body>
      </Card>
    </div>
  );
};

export default CardItem;
