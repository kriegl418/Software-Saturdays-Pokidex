import React from 'react';

export default function PokemonColors({ pokemon }) {
  // Object to map pokemon types to CSS variables
  const typeColors = {
    fire: "--fire",
    water: "--water",
    electric: "--electric",
    grass: "--grass",
    ice: "--ice",
    fighting: "--fighting",
    poison: "--poison",
    ground: "--ground",
    flying: "--flying",
    psychic: "--psychic",
    bug: "--bug",
    rock: "--rock",
    ghost: "--ghost",
    dragon: "--dragon",
    dark: "--dark",
    steel: "--steel",
    fairy: "--fairy"
  }

  // Calculate the average color of all the pokemon
  const colors = pokemon.map(p => typeColors[p.color]);
  const numColors = colors.length;
  const red = colors.reduce((total, c) => total + parseInt(getComputedStyle(document.documentElement).getPropertyValue(c).slice(1, 3), 16), 0) / numColors;
  const green = colors.reduce((total, c) => total + parseInt(getComputedStyle(document.documentElement).getPropertyValue(c).slice(3, 5), 16), 0) / numColors;
  const blue = colors.reduce((total, c) => total + parseInt(getComputedStyle(document.documentElement).getPropertyValue(c).slice(5, 7), 16), 0) / numColors;
  const avgColor = `rgb(${Math.floor(red)}, ${Math.floor(green)}, ${Math.floor(blue)})`;

  return (
    <div style={{ backgroundColor: avgColor }}>
      <h2>The average color of all Pokemon is:</h2>
      <h3>{avgColor}</h3>
    </div>
  );
}
