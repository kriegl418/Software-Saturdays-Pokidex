import React, { useState, useEffect } from 'react';
import PokemonColors from './PokemonColors';
import './Demo3.css'; // Import CSS file with card styles and hover effect


export default function Demo3() {
  const [pokemon, setPokemon] = useState([]);
  const [avgColor, setAvgColor] = useState('#ffffff');
  const [currentPage, setCurrentPage] = useState(1);

  const getAPIData = async (page) => {
    try {
      const response = await fetch(`https://pokeapi.co/api/v2/pokemon?limit=10&offset=${(page - 1) * 10}`);
      const data = await response.json();
      const results = data.results;
      const pokemonList = await Promise.all(
        results.map(async (pokemon) => {
          const response = await fetch(pokemon.url);
          const data = await response.json();
          return {
            id: data.id,
            name: data.name,
            image: data.sprites.front_default,
            color: data.types[0].type.name,
          };
        })
      );
      setPokemon(pokemonList);
    } catch (error) {
      console.log(error);
    }
  };

  useEffect(() => {
    getAPIData(currentPage);
  }, [currentPage]);

  const loadPreviousPage = () => {
    if (currentPage > 1) {
      setCurrentPage(currentPage - 1);
    }
  };

  const loadNextPage = () => {
    setCurrentPage(currentPage + 1);
  };

  return (
    <div style={{ backgroundColor: avgColor }}>
      <PokemonColors pokemon={pokemon} avgColor={avgColor} setAvgColor={setAvgColor} />
      <div className="button-container">
        <button onClick={loadPreviousPage}>Previous Page</button>
        <button onClick={loadNextPage}>Next Page</button>
      </div>
      <h1>Pokemans!</h1>
      <div className="card-container">
        {pokemon.map((pokemon) => (
          <div
            key={pokemon.id}
            className="card"
            style={{ backgroundColor: `var(--${pokemon.color})` }}
          >
            <img src={pokemon.image} alt={pokemon.name} />
            <h3>{pokemon.name}</h3>
          </div>
        ))}
      </div>
    </div>
  );
}
